//========================================Normal_Web_Page_Replace_POST_START========================================
//eval(Parameter_Base_STR_ijk_XX(5));

//<script.*?</script>|<iframe.*?</iframe>|^[ |	]*|[ |	]*$;
//<script[\s\S]*?</script>|<iframe[\s\S]*?</iframe>|^[ |	]*|[ |	]*$;
text_fdn;text_fn;text_ct;
var text_fdn_cache,text_fn_cache,text_ct_cache;
var file_id_len,file_id;
var file_id_len_in_a_folder;
var folder_id_len,folder_id;
//lastModified=File_lastModified;
//lastModified_str=File_lastModified_Time_STR;
//==============================Text_CT_Replace==============================
//====================Sample_00====================
//text_ct=text_ct.replace(new RegExp("<script[\\s\\S]*?</script>|<iframe[\\s\\S]*?</iframe>|^[ |	]*|[ |	]*$","gmi"),"");
//text_ct=text_ct.replace(/^(.+)(img\.ivsky\.com.+)$/gm,"https:\/\/$2").replace(/\\/gm,"\/");
//====================Sample_00====================
//====================Sample_01_No_Repeat_Line_00====================
//text_ct=text_ct.replace(/\r\n/gm,"\n")
//		.split("\n").sort().join("\n")
//		.replace(/^(.+)_ALL\n\1_DLED/gm,"").replace(/^(.+)\t_ALL$/gm,"$1")
//		.split("\n").sort().join("\n")
//		.replace(/[\n]+/gm,"\n");
//text_ct=("��" + text_ct + "��").replace(/^��[\n]*/gm,"").replace(/[\n]*��$/gm,"\n")
//		.replace(/\n/gm,"\r\n");
//====================Sample_01_No_Repeat_Line_00====================
//====================Sample_01_No_Repeat_Line_01====================
var Code_Area=1;
if ( Code_Area==0 )
{
	//text_ct=JSON.stringify(JSON.parse(text_ct));
	arr00=text_ct.replace(/\r\n/gm,"\n").split("\n");
	for (i=0;i<arr00.length;i++)
	{
		if ( arr00[i]!="" )
		{
			arr00[i]=JSON.stringify(JSON.parse(arr00[i]));
		}
	}
	text_ct=arr00.join("\r\n");
}
else if ( Code_Area==1 )
{
	//text_ct=JSON.stringify(JSON.parse(text_ct));
	function ReadTextFile(oFile)
	{
		if (window.XMLHttpRequest)//code for IE7+, Firefox, Chrome, Opera, Safari
		{
			xmlhttp=new XMLHttpRequest();
		}
		else// code for IE6, IE5
		{
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}

		xmlhttp.open("GET",oFile,false);
		xmlhttp.send();
		var TextDoc=xmlhttp.responseText; 
		return TextDoc;
	}

	if ( text_fn=="���˕rӋ_JSON_ALL_02_Archive_2014+_CAT_01_Decode.txt" )
	{
		arr01=ReadTextFile("http://127.0.0.1/_HD/G/���˕rӋ_JSON_ALL_06_Archive_2014+_DIR_01.txt").replace(/\r\n/gm,"\n").split("\n");
		text_fn="���˕rӋ_JSON_ALL_02_Archive_2014+_CAT_02_Decode.txt";
	}
	else if ( text_fn=="���˕rӋ_JSON_ALL_02_Official_2022-01-25_CAT_01_Decode.txt" )
	{
		arr01=ReadTextFile("http://127.0.0.1/_HD/G/���˕rӋ_JSON_ALL_06_Official_2022-01-25_DIR_01.txt").replace(/\r\n/gm,"\n").split("\n");
		text_fn="���˕rӋ_JSON_ALL_02_Official_2022-01-25_CAT_02_Decode.txt";
	}
	else		{}

	arr00=text_ct.replace(/\r\n/gm,"\n").split("\n");
	for (i=0;i<arr00.length;i++)
	{
		if ( arr00[i]!="" )
		{
			arr00[i]=JSON.stringify(JSON.parse(arr00[i]));
		}
	}
	for (i=0;i<arr00.length;i++)
	{
		if ( arr00[i]!="" )
		{
			arr00[i]=arr01[i] + "\n" + JSON.stringify(JSON.parse(arr00[i]),null,"\t");
		}
	}
	text_ct="=".repeat(80) + "\n" + arr00.join("\n" + "=".repeat(80) + "\n");
	text_ct=text_ct.replace(/\n/gm,"\r\n");

	//	Google Search Result :
	//	[json][json ]
	//	JSON Formatter & Validator
	//	json.stringify file object
	//	json_decode file object
	//	json stringify
	//	json file
	//	json stringify online
	//	json formatter
	//	json stringify pretty
	//	json file example
	//	json object
	//
	//	json validator
	//	json viewer
	//	json beautifier
	//	jsonlint
	//	json file
}
else			{}
//====================Sample_01_No_Repeat_Line_01====================
//====================Sample_01_No_Repeat_Line_02(Speed_Slow)====================
////Multi same line left one .
//str00=text_ct;
//arr00=str00.replace(/\r\n/gm,"\n").split("\n").sort();
//for (i=0;i<(arr00.length - 1);i++)
//{
//	if ( arr00[i]==arr00[i + 1] )
//	{
//		arr00.splice(i + 1,1);
//		i--;
//	}
//	else		{}
//}
//str00=arr00.join("\n");
//text_ct=str00;
//text_ct=("������" + text_ct + "������").replace(/^������[\n]*/gm,"������").replace(/[\n]*������$/gm,"������\n").replace(/������/gm,"")
//		.replace(/\n/gm,"\r\n");
//====================Sample_01_No_Repeat_Line_02(Speed_Slow)====================
//==============================Text_CT_Replace==============================

formData=new FormData_SD();
formData_ARR=[];
var formData_num=0;
//str02="";
num02=0;
file_id_len=2;
file_id_len_in_a_folder=2;
folder_id_len=file_id_len - file_id_len_in_a_folder;

//====================Save_Info====================
text_ct_cache=text_ct;
//text_ct=encodeURIComponent(text_ct);
//file_id=("000000" + num02.toString()).slice(-6);
file_id=("0".repeat(file_id_len) + num02.toString()).slice(-file_id_len);
folder_id=file_id.slice(0,folder_id_len);
text_fn_cache=text_fn;

file_000000=new File_SD(
	[text_ct_cache],
	text_fn_cache,
	{
		type:			"text/plain",
		//type:			"text/plain___",// + "X".repeat(1024) + "Y",
		lastModified:	""
	});
text_fdn_cache=text_fdn;
text_fdn_cache=text_fdn + "\\" + folder_id + "\\";
text_fdn_cache=text_fdn_cache.replace(/[\\]+/gm,"\\\\");
formData.append("file_" + file_id,file_000000);

str02="array(\"folder_" + file_id + "\",\"" + text_fdn_cache + "\")" + "\n";
num02=1;
formData_num=1;

formData.append("folder_list_str",str02);
formData.append("file_num",formData_num);
formData.append("file_id_start",(num02 - formData_num));
formData.append("file_id_len",file_id_len);
formData.append("formData_append_parameter_type",1);

formData_ARR.push(formData);

//alert("==" + file_id + "==\n==" + folder_id + "==\n==" + text_ct_cache + "==\n==" + text_fn_cache + "==\n==" + text_fdn_cache + "==\n==");
//alert("==" + str02 + "==\n==" + formData_num + "==\n==" + (num02 - formData_num) + "==\n==" + file_id_len + "==\n==");

//====================Save_Info====================
text_ct="";
php_request_method="POST";

//lastModified=0;
//lastModified_str="";

//text_ct=encodeURIComponent(text_ct);
//========================================Normal_Web_Page_Replace_POST_OVER========================================
